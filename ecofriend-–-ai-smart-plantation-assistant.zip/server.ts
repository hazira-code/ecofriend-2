import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dns from "dns";

// Fix Node dns resolution timing in some container environments
dns.setDefaultResultOrder("ipv4first");

const app = express();
const PORT = 3000;

// Increase payload sizes for base64 leaf image uploads
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ limit: "20mb", extended: true }));

// Initialize Gemini SDK with named parameters as instructed
const geminiApiKey = process.env.GEMINI_API_KEY || "";
let aiClient: any = null;

if (geminiApiKey) {
  try {
    aiClient = new GoogleGenAI({
      apiKey: geminiApiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("Successfully initialized GoogleGenAI client with key.");
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
  }
} else {
  console.warn("GEMINI_API_KEY is not defined. AI features will fallback to high-quality responsive mocked bilingual data.");
}

// Custom Middleware to check if Gemini AI Client is available
const checkAi = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!aiClient) {
    req.aiAvailable = false;
  } else {
    req.aiAvailable = true;
  }
  next();
};

declare global {
  namespace Express {
    interface Request {
      aiAvailable?: boolean;
    }
  }
}

app.use(checkAi);

// ==================== API ROUTE HANDLERS ====================

// 1. Plant Recommendations
app.post("/api/recommend", async (req, res) => {
  const { climate, sunlight, soilType, water } = req.body;

  if (!climate || !sunlight || !soilType || !water) {
    return res.status(400).json({ error: "Missing required parameters" });
  }

  if (!req.aiAvailable) {
    return res.json(getMockRecommendations(climate, sunlight, soilType, water));
  }

  try {
    const prompt = `Recommend 3 suitable plants for a regional gardener with these conditions:
- Climate: ${climate}
- Sunlight Exposure: ${sunlight}
- Soil Type: ${soilType}
- Water Availability: ${water}

Provide the recommendations in a valid JSON array format. Strictly follow this exact schema:
[
  {
    "name": "Plant Name in English",
    "teluguName": "Plant Name in Telugu",
    "description": "An eco-friendly, student-friendly introduction to growing this plant",
    "teluguDescription": "తెలుగులో ఈ మొక్కను పెంచడానికి అవసరమైన ఉపోద్ఘాతం",
    "growthTime": "Estimated time to harvest or mature size (e.g. 60-90 days)",
    "sunlightRequired": "Sunlight advice (e.g. Full sun, partial shade)",
    "soilRequired": "Soil advice (e.g. Loamy or Sandy)",
    "waterRequired": "Water requirements",
    "careTips": ["Tip 1 in English", "Tip 2 in English"],
    "careTipsTelugu": ["తెలుగు చిట్కా 1", "తెలుగు చిట్కా 2"]
  }
]`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              teluguName: { type: Type.STRING },
              description: { type: Type.STRING },
              teluguDescription: { type: Type.STRING },
              growthTime: { type: Type.STRING },
              sunlightRequired: { type: Type.STRING },
              soilRequired: { type: Type.STRING },
              waterRequired: { type: Type.STRING },
              careTips: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              careTipsTelugu: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              "name",
              "teluguName",
              "description",
              "teluguDescription",
              "growthTime",
              "sunlightRequired",
              "soilRequired",
              "waterRequired",
              "careTips",
              "careTipsTelugu",
            ],
          },
        },
      },
    });

    res.json(JSON.parse(response.text || "[]"));
  } catch (error: any) {
    console.error("Gemini /api/recommend error:", error);
    res.json(getMockRecommendations(climate, sunlight, soilType, water));
  }
});

// 2. Soil Guidance & Fertility Recommendations
app.post("/api/soil-guidance", async (req, res) => {
  const { soilType, currentCondition } = req.body;

  if (!soilType || !currentCondition) {
    return res.status(400).json({ error: "Missing required parameters" });
  }

  if (!req.aiAvailable) {
    return res.json(getMockSoilGuidance(soilType, currentCondition));
  }

  try {
    const prompt = `Analyze this soil setup and suggest improvement methods bilingually:
- Soil Type: ${soilType}
- Current Visual Condition / Moisture: ${currentCondition}

Deliver a valid JSON response matching this schema:
{
  "bestCrops": ["Crop 1 (క్రోప్ 1)", "Crop 2 (క్రోప్ 2)"],
  "fertilityRating": "High/Medium/Low based on description",
  "fertilityTips": ["Tip 1 in English", "Tip 2 in English"],
  "fertilityTipsTelugu": ["తెలుగు పోషణ చిట్కా 1", "తెలుగు పోషణ చిట్కా 2"],
  "compostSuggestions": ["Compost 1 in English", "Compost 2 in English"],
  "compostSuggestionsTelugu": ["తెలుగు సేంద్రియ ఎరువు చిట్కా 1", "తెలుగు సేంద్రియ ఎరువు చిట్కా 2"]
}`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bestCrops: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            fertilityRating: { type: Type.STRING },
            fertilityTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            fertilityTipsTelugu: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            compostSuggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            compostSuggestionsTelugu: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: [
            "bestCrops",
            "fertilityRating",
            "fertilityTips",
            "fertilityTipsTelugu",
            "compostSuggestions",
            "compostSuggestionsTelugu",
          ],
        },
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    console.error("Gemini /api/soil-guidance error:", error);
    res.json(getMockSoilGuidance(soilType, currentCondition));
  }
});

// 3. Water Quantity Prediction
app.post("/api/water-prediction", async (req, res) => {
  const { plantName, climate, temperature, stage } = req.body;

  if (!plantName) {
    return res.status(400).json({ error: "plantName is required" });
  }

  const tempNum = Number(temperature) || 28;

  if (!req.aiAvailable) {
    return res.json(getMockWaterPrediction(plantName, climate, tempNum, stage));
  }

  try {
    const prompt = `Predict accurate outdoor/indoor watering specifications for:
- Plant Name: ${plantName}
- Climate Region: ${climate || "Tropical"}
- Temperature: ${tempNum}°C
- Growth Stage: ${stage || "Seedling"}

Deliver a valid JSON response matching this schema:
{
  "dailyRequirement": "Water required in milliliters (e.g. 250ml - 350ml)",
  "wateringFrequency": "Frequency (e.g. Once daily, twice daily etc.)",
  "irrigationType": "Irrigation technique in English",
  "irrigationTypeTelugu": "నీటి పారుదల పద్ధతి తెలుగులో",
  "tips": ["Water tip 1 in English", "Water tip 2 in English"],
  "tipsTelugu": ["నీటి చిట్కా 1 తెలుగులో", "నీటి చిట్కా 2 తెలుగులో"]
}`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dailyRequirement: { type: Type.STRING },
            wateringFrequency: { type: Type.STRING },
            irrigationType: { type: Type.STRING },
            irrigationTypeTelugu: { type: Type.STRING },
            tips: { type: Type.ARRAY, items: { type: Type.STRING } },
            tipsTelugu: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            "dailyRequirement",
            "wateringFrequency",
            "irrigationType",
            "irrigationTypeTelugu",
            "tips",
            "tipsTelugu",
          ],
        },
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    console.error("Gemini /api/water-prediction error:", error);
    res.json(getMockWaterPrediction(plantName, climate, tempNum, stage));
  }
});

// 4. Climate Suitability
app.post("/api/climate-suitability", async (req, res) => {
  const { plantName, location, temperature, humidity } = req.body;

  if (!plantName) {
    return res.status(400).json({ error: "plantName is required" });
  }

  const tempNum = Number(temperature) || 30;
  const humidNum = Number(humidity) || 60;

  if (!req.aiAvailable) {
    return res.json(getMockClimateSuitability(plantName, location, tempNum, humidNum));
  }

  try {
    const prompt = `Detailed climate capability analysis for:
- Plant: ${plantName}
- Location context: ${location || "India"}
- Local Temperature: ${tempNum}°C
- Humidity Level: ${humidNum}%

Deliver a valid JSON response matching this schema:
{
  "suitabilityScore": 85, // integer 0 to 100
  "isSuitable": true, // boolean
  "analysis": "Environmental viability analysis in English",
  "analysisTelugu": "శీతోష్ణస్థితి అనుకూలత విశ్లేషణ తెలుగులో",
  "precautions": ["Precautions in English if weather is too extreme"],
  "precautionsTelugu": ["తెలుగులో రక్షణ చర్యలు (వ్యాధులు రాకుండా తీసుకునే జాగ్రత్తలు)"]
}`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suitabilityScore: { type: Type.INTEGER },
            isSuitable: { type: Type.BOOLEAN },
            analysis: { type: Type.STRING },
            analysisTelugu: { type: Type.STRING },
            precautions: { type: Type.ARRAY, items: { type: Type.STRING } },
            precautionsTelugu: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            "suitabilityScore",
            "isSuitable",
            "analysis",
            "analysisTelugu",
            "precautions",
            "precautionsTelugu",
          ],
        },
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    console.error("Gemini /api/climate-suitability error:", error);
    res.json(getMockClimateSuitability(plantName, location, tempNum, humidNum));
  }
});

// 5. Leaf Disease Detection
app.post("/api/disease-detection", async (req, res) => {
  const { image } = req.body; // Base64 encoded crop leaf image

  if (!image) {
    return res.status(400).json({ error: "Base64 image is required in request body" });
  }

  if (!req.aiAvailable) {
    return res.json(getMockDiseaseDetection());
  }

  try {
    // Extract base64 prefix if exists
    let cleanBase64 = image;
    let mimeType = "image/jpeg";
    if (image.includes(",")) {
      const parts = image.split(",");
      cleanBase64 = parts[1];
      const match = parts[0].match(/:(.*?);/);
      if (match) mimeType = match[1];
    }

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: cleanBase64,
      },
    };

    const textPart = {
      text: `Identify any botanical diseases found in this leaf photo. Explain the findings and organic solutions.
Deliver a valid JSON response strictly following this schema:
{
  "detectedDisease": "Name of disease in English (or Healthy Leaf if no disease)",
  "detectedDiseaseTelugu": "తెలుగులో వ్యాధి పేరు (లేదా ఆరోగ్యకరమైన ఆకు)",
  "confidenceScore": 92, // estimated confidence from 0 to 100
  "remedies": ["Organic remedy steps in English"],
  "remediesTelugu": ["సేంద్రియ నివారణ చర్యలు తెలుగులో"],
  "preventions": ["Botanical preventive steps in English"],
  "preventionsTelugu": ["వ్యాధి రాకుండా ముందస్తు సమాచారం తెలుగులో"]
}`,
    };

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedDisease: { type: Type.STRING },
            detectedDiseaseTelugu: { type: Type.STRING },
            confidenceScore: { type: Type.INTEGER },
            remedies: { type: Type.ARRAY, items: { type: Type.STRING } },
            remediesTelugu: { type: Type.ARRAY, items: { type: Type.STRING } },
            preventions: { type: Type.ARRAY, items: { type: Type.STRING } },
            preventionsTelugu: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            "detectedDisease",
            "detectedDiseaseTelugu",
            "confidenceScore",
            "remedies",
            "remediesTelugu",
            "preventions",
            "preventionsTelugu",
          ],
        },
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    console.error("Gemini /api/disease-detection error:", error);
    res.json(getMockDiseaseDetection());
  }
});

// 6. AI Chatbot (Supports history & English + Telugu)
app.post("/api/chat", async (req, res) => {
  const { message, chatHistory } = req.body;

  if (!message) {
    return res.status(400).json({ error: "message is required" });
  }

  if (!req.aiAvailable) {
    return res.json(getMockChatResponse(message));
  }

  try {
    // Generate simple chatbot greeting / solution
    const formattedHistory = (chatHistory || [])
      .map((item: any) => `${item.sender === "user" ? "User" : "Assistant"}: ${item.text}`)
      .join("\n");

    const prompt = `You are EcoFriend AI, a warm greenhouse/botany companion helping beginners and school students.
Answer this horticulture question bilingually:
"${message}"

Chat Context/History:
${formattedHistory}

Always respond in a clean JSON format containing:
{
  "reply": "Your friendly detailed reply in English with garden advice",
  "replyTelugu": "అదే సమాధానం సరళమైన మరియు స్పష్టమైన తెలుగులో"
}`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING },
            replyTelugu: { type: Type.STRING },
          },
          required: ["reply", "replyTelugu"],
        },
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    console.error("Gemini /api/chat error:", error);
    res.json(getMockChatResponse(message));
  }
});

// 7. Growth Prediction
app.post("/api/growth-prediction", async (req, res) => {
  const { plantName, CareLevel, soilQuality } = req.body;

  if (!plantName) {
    return res.status(400).json({ error: "plantName is required" });
  }

  if (!req.aiAvailable) {
    return res.json(getMockGrowthPrediction(plantName, CareLevel, soilQuality));
  }

  try {
    const prompt = `Analyze botanical data and estimate organic yield outcomes for:
- Plant Species: ${plantName}
- Care Routine Diligence: ${CareLevel || "Moderate Care"}
- Ground Soil Quality: ${soilQuality || "Medium Fertility"}

Deliver a valid JSON response matching this schema:
{
  "currentStage": "Recommended initial planting phase in English (e.g., Sowing the seed)",
  "currentStageTelugu": "తెలుగులో ప్రాథమిక దశ (ఉదా. గింజ నాటడం)",
  "nextMilestone": "Next critical growing milestone details in English",
  "nextMilestoneTelugu": "తదుపరి మైలురాయి తెలుగులో",
  "estimatedHarvestDate": "Approximate days till reward (e.g. 75 Days)",
  "yieldEstimate": "Expected yield under standard conditions (e.g. 1.2kg per plant)",
  "yieldEstimateTelugu": "తెలుగులో దిగుబడి అంచనా",
  "milestones": [
    {
      "day": "Day 1-10",
      "stage": "Sprouting",
      "stageTelugu": "మొలక దశ",
      "details": "Keep soil moist and warm for high rate germination.",
      "detailsTelugu": "మొలకలు రావడానికి మట్టిని తేమగా ఉంచండి."
    },
    {
      "day": "Day 15-40",
      "stage": "Vegetative Growth",
      "stageTelugu": "శాఖీయ పెరుగుదల దశ",
      "details": "Introduce compost / organic manure once in two weeks.",
      "detailsTelugu": "రెండు వారాలకు ఒకసారి సేంద్రియ ఎరువులు అందించండి."
    },
    {
      "day": "Day 45-70",
      "stage": "Flowering & Fruiting",
      "stageTelugu": "పూత మరియు పిందె దశ",
      "details": "Provide stable direct sun. Prune yellowed leaves carefully.",
      "detailsTelugu": "రక్షిత సూర్యకాంతి అందించండి, పండిన ఆకులను కత్తిరించండి."
    }
  ]
}`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            currentStage: { type: Type.STRING },
            currentStageTelugu: { type: Type.STRING },
            nextMilestone: { type: Type.STRING },
            nextMilestoneTelugu: { type: Type.STRING },
            estimatedHarvestDate: { type: Type.STRING },
            yieldEstimate: { type: Type.STRING },
            yieldEstimateTelugu: { type: Type.STRING },
            milestones: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.STRING },
                  stage: { type: Type.STRING },
                  stageTelugu: { type: Type.STRING },
                  details: { type: Type.STRING },
                  detailsTelugu: { type: Type.STRING },
                },
                required: ["day", "stage", "stageTelugu", "details", "detailsTelugu"],
              },
            },
          },
          required: [
            "currentStage",
            "currentStageTelugu",
            "nextMilestone",
            "nextMilestoneTelugu",
            "estimatedHarvestDate",
            "yieldEstimate",
            "yieldEstimateTelugu",
            "milestones",
          ],
        },
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error) {
    console.error("Gemini /api/growth-prediction error:", error);
    res.json(getMockGrowthPrediction(plantName, CareLevel, soilQuality));
  }
});

// 8. Voice Assistant - Premium Text To Speech generating Telugu/English audio!
app.post("/api/tts", async (req, res) => {
  const { text, language } = req.body;

  if (!text) {
    return res.status(400).json({ error: "text is required" });
  }

  if (!req.aiAvailable) {
    return res.status(400).json({ error: "Gemini client offline" });
  }

  try {
    const speakPrompt = language === "te"
      ? `మాట్లాడండి: ఏకోఫ్రెండ్ స్మార్ట్ ప్లాంటేషన్ సహాయకుడికి స్వాగతం. ${text}`
      : `Say cheerfully: Welcome to EcoFriend smart plantation assistant. ${text}`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: speakPrompt }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Kore" },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audio: base64Audio });
    } else {
      res.status(500).json({ error: "TTS generation returned empty audio data stream" });
    }
  } catch (error: any) {
    console.error("Gemini TTS API error:", error);
    res.status(500).json({ error: error.message || "Failed to generate TTS audio stream" });
  }
});


// ==================== BACKUP ROBUST BILINGUAL MOCKED DATA ====================

function getMockRecommendations(climate: string, sunlight: string, soilType: string, water: string) {
  return [
    {
      name: "Holy Basil (Tulsi)",
      teluguName: "తులసి (Tulsi)",
      description: "Tulsi is a highly revered medicinal plant. It grows exceptionally well in warm climates and requires moderate watering.",
      teluguDescription: "తులసి ఒక పురాతన ఔషధ గుణాలు గల మొక్క. ఇది వెచ్చని వాతావరణంలో బాగా పెరుగుతుంది మరియు మధ్యస్థ నీరు సరిపోతుంది.",
      growthTime: "30-45 Days to mature size",
      sunlightRequired: "Full Sun (6+ hours daily)",
      soilRequired: "Rich, well-draining loamy soil",
      waterRequired: "Moderate watering (keep soil moist but not soggy)",
      careTips: [
        "Pinch off the flower heads to encourage bushier leaf growth.",
        "Ensure pot has a good drainage hole to avoid root rot."
      ],
      careTipsTelugu: [
        "ఆకులు గుబురుగా పెరగడానికి పైన పూత మొగ్గలను కత్తిరించండి.",
        "వేళ్ళు కుళ్ళిపోకుండా ఉండటానికి కుండీలో నీరు బయటకు పోయే రంధ్రం ఉండేలా చూసుకోండి."
      ]
    },
    {
      name: "Marigold (Banthi)",
      teluguName: "బంతి పూలు (Marigold)",
      description: "Bright yellow marigolds acts as natural pest repellents, perfect for borders of school gardens.",
      teluguDescription: "బంతి పువ్వులు సహజంగా కీటకాలను నివారిస్తాయి. పాఠశాల/కళాశాల తోటల బోర్డర్ల కోసం ఈ మొక్కలు ఎంతో అనుకూలం.",
      growthTime: "45-60 Days",
      sunlightRequired: "Direct Solar Light (6-8 hours)",
      soilRequired: "Sandy or standard garden soil",
      waterRequired: "Low Water (Water twice a week)",
      careTips: [
        "Deadhead dried flowers weekly to increase bloom cycle.",
        "Protect seed beds from deep soil flooding."
      ],
      careTipsTelugu: [
        "మరిన్ని పూలు పూయడానికి ఎండిపోయిన పూలను వెంటనే కత్తిరించండి.",
        "మట్టిలో నీరు ఎక్కువగా నిలవకుండా కాపాడుకోండి."
      ]
    },
    {
      name: "Tomato (Tomato)",
      teluguName: "టమోటా (Tomato)",
      description: "Quick bearing kitchen gardening staple. Easy for school projects and yields organic crop within weeks.",
      teluguDescription: "త్వరగా కాయలు కాచే ఇంటి పంట. విద్యార్థుల ప్రాజెక్ట్‌లకు ఎంతో సరిపోతుంది మరియు కొద్ది వారాల్లోనే దిగుబడి ఇస్తుంది.",
      growthTime: "60-80 Days",
      sunlightRequired: "Full intense morning sunlight",
      soilRequired: "Nutrient-dense loamy compost-rich soil",
      waterRequired: "Moderate (Daily consistent misting)",
      careTips: [
        "Provide support stakes or cages as tomato vines grow heavy.",
        "Water bottom soil directly instead of splashing leaves."
      ],
      careTipsTelugu: [
        "టమోటా కొమ్మలు బరువు పెరుగుతున్నప్పుడు కర్రల సహాయం (సపోర్ట్) అందించండి.",
        "ఆకులపై నీరు చల్లకుండా నేరుగా మట్టిలోనే నీళ్ళు పోయండి."
      ]
    }
  ];
}

function getMockSoilGuidance(soilType: string, condition: string) {
  return {
    bestCrops: ["Legumes / Beans (చిక్కుడు)", "Spinach (పాలకూర)", "Holy Basil (తులసి)"],
    fertilityRating: "Medium Fertile (మధ్యస్థ సారవంతమైనది)",
    fertilityTips: [
      "Add natural dry leaves manure to enrich organic nitrogen levels.",
      "Till the top soil layer gently to enhance aeration."
    ],
    fertilityTipsTelugu: [
      "నైట్రోజన్ శాతాన్ని పెంచడానికి సహజ ఎండిన ఆకుల కంపోస్ట్ జోడించండి.",
      "మట్టి లోపలికి గాలి బాగా వెళ్ళడానికి మట్టిని నెమ్మదిగా గుల్ల చేయండి."
    ],
    compostSuggestions: [
      "Vermicompost (Earthworm castings) or tea wastes manure.",
      "Eggshell powder to introduce robust calcium reserves."
    ],
    compostSuggestionsTelugu: [
      "వర్మికంపోస్ట్ (వానపాముల ఎరువు) లేదా వాడిన టీ పొడిని ఎరువుగా వాడండి.",
      "కాల్షియం పెరగడానికి ఎండిన కోడిగుడ్డు పెంకుల పొడిని జోడించండి."
    ]
  };
}

function getMockWaterPrediction(plantName: string, climate: string, temp: number, stage: string) {
  return {
    dailyRequirement: `${temp > 32 ? "350ml - 500ml" : "200ml - 300ml"} daily`,
    wateringFrequency: "Once in the early morning",
    irrigationType: "Drip Irrigation or Fine Misting Spray",
    irrigationTypeTelugu: "బిందు సేద్యం (డ్రిప్) లేదా స్ప్రే పద్ధతి",
    tips: [
      "Always check the top 1 inch of soil. If it is dry, irrigate immediately.",
      "Watering in high afternoon sun can evaporate the moisture quickly. Prefer early mornings."
    ],
    tipsTelugu: [
      "పై మట్టి 1 అంగుళం పొడిగా ఉందో లేదో ఎప్పటికప్పుడు తనిఖీ చేసి నీరు పోయండి.",
      "మధ్యాహ్నపు ఎండలో నీళ్ళు పోయవద్దు ఎందుకంటే నీరు త్వరగా ఆవిరైపోతుంది. ఉదయమే అనుకూలం."
    ]
  };
}

function getMockClimateSuitability(plantName: string, location: string, temp: number, humidity: number) {
  const isSuitable = temp >= 18 && temp <= 38;
  const score = isSuitable ? 90 - Math.abs(28 - temp) : 45;
  return {
    suitabilityScore: score,
    isSuitable: isSuitable,
    analysis: `${plantName} shows optimal vegetative progress at ${temp}°C in ${location || "local climate"}. Good metabolic cycles.`,
    analysisTelugu: `${plantName} మొక్క ${temp}°C ఉష్ణోగ్రత వద్ద చాలా బాగా ఎదుగుతుంది. సహజ వాతావరణంలో ఉత్తమ లాభాలు ఇస్తుంది.`,
    precautions: [
      temp > 35 ? "Protect from heavy scorching sun with a green shed net." : "Keep in open air for adequate daylight absorption."
    ],
    precautionsTelugu: [
      temp > 35 ? "ఎండ తీవ్రత ఎక్కువగా ఉంటే మొక్కలపై గ్రీన్ షేడ్ నెట్ నిర్మించండి." : "సరిపడా సూర్యకాంతి తగిలేలా ఆరుబయట ఉంచండి."
    ]
  };
}

function getMockDiseaseDetection() {
  return {
    detectedDisease: "Cercospora Leaf Spot (ఆకు మచ్చ తెగులు)",
    detectedDiseaseTelugu: "సెర్కోస్పోరా ఆకు మచ్చ తెగులు",
    confidenceScore: 88,
    remedies: [
      "Spray organic Neem Oil solution (5ml dissolved in 1L water with mild soap) once in 3 days.",
      "Carefully prune and burn deeply affected leaves to stop further fungus spread."
    ],
    remediesTelugu: [
      "వేప నూనె ద్రావణాన్ని (1 లీటర్ నీటిలో 5మి.లీ వేప నూనె, కొద్దిగా సబ్బు ద్రావణంతో) 3 రోజులకు ఒకసారి స్ప్రే చేయండి.",
      "ఫంగస్ పెరగకుండా ఉండటానికి బాగా ఎండిపోయిన ప్రతీ పండిన ఆకును కత్తిరించి కాల్చివేయండి."
    ],
    preventions: [
      "Avoid overhead watering of plant leaves in late evenings; water the root level instead.",
      "Maintain active air circulation spacing between crops."
    ],
    preventionsTelugu: [
      "సాయంత్రం పూట ఆకులపై నీరు చల్లకుండా కేవలం వేరు భాగంలోనే తగినంత నీళ్ళు పోయండి.",
      "మొక్కల మధ్య సరైన గాలి తగిలేలా కొంచెం దూరం పాటించండి."
    ]
  };
}

function getMockChatResponse(msg: string) {
  return {
    reply: `That is an excellent gardening query about: "${msg}". Beginners should focus on healthy soil prep (with organic compost), ensuring adequate 6 hours of sun, and watering Tulsi, Marigolds or Tomatoes directly at root level. Feel free to ask more specific questions about plant diseases or soil fertilizer guides.`,
    replyTelugu: `మీరు చాలా మంచి ప్రశ్న అడిగారు: "${msg}". తోటపని ప్రారంభించే విద్యార్థులు మొదటగా సారవంతమైన మట్టిని తయారు చేసుకోవడంపై దృష్టి పెట్టాలి. రోజూ 6 గంటల సూర్యరశ్మి మరియు ఉదయమే నీళ్ళు పోయడం చాలా అవసరం. తవ్వకం లేదా ఫంగస్ వ్యాధుల నివారణ గురించి నన్ను ఏ ప్రశ్నైనా అడగవచ్చు.`
  };
}

function getMockGrowthPrediction(plantName: string, careLevel: string, soilQuality: string) {
  return {
    currentStage: "Vegetative Growth Phase",
    currentStageTelugu: "శాఖీయ ఎదుగుదల దశ",
    nextMilestone: "Flowering & Buds formation",
    nextMilestoneTelugu: "మొగ్గలు తొడగడం మరియు పూత పూసే సమయం",
    estimatedHarvestDate: "45-60 Days",
    yieldEstimate: "0.5kg to 1.5kg organic harvest per pot pod",
    yieldEstimateTelugu: "ప్రతీ కుండీ నుండి 0.5 కిలోల నుండి 1.5 కిలోల తాజా దిగుబడి",
    milestones: [
      {
        day: "Day 1-10",
        stage: "Sowing & Germination",
        stageTelugu: "విత్తనం నాటడం మరియు మొలకెత్తడం",
        details: "Place seeds in warm dark space, keep moisture stable without overflooding.",
        detailsTelugu: "విత్తనాన్ని తగినంత తేమగా ఉంచండి, నీళ్ళు ఎక్కువ కాకుండా నివారించండి."
      },
      {
        day: "Day 15-30",
        stage: "Early Leaf Stems",
        stageTelugu: "ప్రాథమిక ఆకులు వచ్చే దశ",
        details: "Expose to soft morning sun. Ensure soil tilling regularly.",
        detailsTelugu: "ఉదయం పూట ఎండలో ఉంచండి. మట్టిని క్రమం తప్పకుండా గుల్ల చేస్తూ ఉండండి."
      },
      {
        day: "Day 35-50",
        stage: "Bud Production",
        stageTelugu: "మొగ్గలు వేసే దశ",
        details: "Introduce organic leaf compost or liquid fertilizers to support blooms.",
        detailsTelugu: "మొక్క బలంగా పెరిగి మొగ్గలు రావడానికి సేంద్రియ ద్రావణాల ఎరువులను జోడించండి."
      }
    ]
  };
}


// Vite / Serve Integration Setup based on guidelines
const isProduction = process.env.NODE_ENV === "production";

if (!isProduction) {
  createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  }).then((vite) => {
    app.use(vite.middlewares);
    
    // Serve index.html or fallback
    app.use("*", async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>EcoFriend – AI Smart Plantation Assistant</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`;
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server launched on environment. Listening at http://localhost:${PORT}`);
    });
  });
} else {
  const distPath = path.join(process.cwd(), "dist");
  app.use(express.static(distPath));
  
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Production server running and accessible on port ${PORT}`);
  });
}
